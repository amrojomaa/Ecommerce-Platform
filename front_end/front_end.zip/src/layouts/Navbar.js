import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../hooks/useAuth';
import { useCart } from '../hooks/useCart';
import { useTheme } from '../hooks/useTheme';
import '../styles/layouts/Navbar.css';

const Navbar = () => {
  const { isAuthenticated, user, logout, isAdmin } = useAuth();
  const { getCartItemCount } = useCart();
  const { isDarkMode, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const cartItemCount = getCartItemCount();
  
  // Safety check for isAdmin
  const checkIsAdmin = () => {
    return isAdmin && typeof isAdmin === 'function' ? isAdmin() : false;
  };
  
  // Check if motion is available, fallback to regular elements if not
  // Ensure we always have a valid component, never undefined
  const NavComponent = (motion && typeof motion.nav !== 'undefined') ? motion.nav : 'nav';
  const SpanComponent = (motion && typeof motion.span !== 'undefined') ? motion.span : 'span';
  const DivComponent = (motion && typeof motion.div !== 'undefined') ? motion.div : 'div';
  
  // Final safety check - if any component is still undefined, use string fallback
  const SafeNavComponent = NavComponent || 'nav';
  const SafeSpanComponent = SpanComponent || 'span';
  const SafeDivComponent = DivComponent || 'div';

  return (
    <SafeNavComponent
      className={`navbar ${isDarkMode ? 'dark' : ''}`}
      {...(motion ? {
        initial: { y: -100 },
        animate: { y: 0 },
        transition: { duration: 0.5 }
      } : {})}
    >
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <SafeSpanComponent
            {...(motion ? {
              whileHover: { scale: 1.05 },
              whileTap: { scale: 0.95 }
            } : {})}
            style={{ display: 'inline-block' }}
          >
            E-Commerce
          </SafeSpanComponent>
        </Link>

        <div className="navbar-menu">
          <Link to="/products" className="navbar-link">
            Products
          </Link>
          
          {isAuthenticated ? (
            <>
              <Link to="/cart" className="navbar-link cart-link">
                Cart
                {cartItemCount > 0 && (
                  <span className="cart-badge">{cartItemCount}</span>
                )}
              </Link>
              <Link to="/orders" className="navbar-link">
                My Orders
              </Link>
              <Link to="/profile" className="navbar-link">
                Profile
              </Link>
              {checkIsAdmin() && (
                <Link to="/admin" className="navbar-link admin-link">
                  Admin
                </Link>
              )}
              <div className="navbar-user">
                <span className="user-email">{user?.email}</span>
                <button onClick={handleLogout} className="logout-btn">
                  Logout
                </button>
              </div>
            </>
          ) : (
            <>
              <Link to="/login" className="navbar-link">
                Login
              </Link>
              <Link to="/signup" className="navbar-link signup-link">
                Sign Up
              </Link>
            </>
          )}

          <button
            onClick={toggleTheme}
            className="theme-toggle"
            aria-label="Toggle theme"
          >
            {isDarkMode ? '☀️' : '🌙'}
          </button>

          <button
            className="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <SafeDivComponent
          className="mobile-menu"
          {...(motion ? {
            initial: { opacity: 0, height: 0 },
            animate: { opacity: 1, height: 'auto' },
            exit: { opacity: 0, height: 0 }
          } : {})}
        >
          <Link to="/products" onClick={() => setMobileMenuOpen(false)}>
            Products
          </Link>
          {isAuthenticated ? (
            <>
              <Link to="/cart" onClick={() => setMobileMenuOpen(false)}>
                Cart ({cartItemCount})
              </Link>
              <Link to="/orders" onClick={() => setMobileMenuOpen(false)}>
                My Orders
              </Link>
              <Link to="/profile" onClick={() => setMobileMenuOpen(false)}>
                Profile
              </Link>
              {checkIsAdmin() && (
                <Link to="/admin" onClick={() => setMobileMenuOpen(false)}>
                  Admin
                </Link>
              )}
              <button onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
                Login
              </Link>
              <Link to="/signup" onClick={() => setMobileMenuOpen(false)}>
                Sign Up
              </Link>
            </>
          )}
        </SafeDivComponent>
      )}
    </SafeNavComponent>
  );
};

export default Navbar;
