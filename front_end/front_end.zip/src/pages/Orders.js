import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import { formatPrice, formatDate } from '../utils/helpers';
import LoadingSpinner from '../components/LoadingSpinner';
import '../styles/pages/Orders.css';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      // Note: This endpoint may need to be added to your FastAPI backend
      // For now, we'll show a placeholder message
      // const response = await http.get('/orders/my');
      // setOrders(response.data);
      
      // Placeholder - replace with actual API call when endpoint is available
      setOrders([]);
      toast.info('Orders endpoint not yet implemented in backend');
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="orders-loading">
        <LoadingSpinner size="large" />
      </div>
    );
  }

  return (
    <div className="orders-page">
      <h1>My Orders</h1>
      
      {orders.length === 0 ? (
        <motion.div
          className="empty-orders"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <p>You haven't placed any orders yet.</p>
          <Link to="/products" className="shop-link">
            Start Shopping
          </Link>
        </motion.div>
      ) : (
        <div className="orders-list">
          {orders.map((order, index) => (
            <motion.div
              key={order.id}
              className="order-card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="order-header">
                <div>
                  <h3>Order #{order.id}</h3>
                  <p className="order-date">
                    {formatDate(order.created_at)}
                  </p>
                </div>
                <div className="order-total">
                  {formatPrice(order.total_amount)}
                </div>
              </div>

              <div className="order-items">
                {order.items?.map((item) => (
                  <div key={item.id} className="order-item">
                    <div className="order-item-info">
                      <h4>{item.product?.name || 'Product'}</h4>
                      <p>Quantity: {item.quantity}</p>
                    </div>
                    <div className="order-item-price">
                      <p>{formatPrice(item.price)} each</p>
                      <p className="item-total">{formatPrice(item.total)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Orders;
