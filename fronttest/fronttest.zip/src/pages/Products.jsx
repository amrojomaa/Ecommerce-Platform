import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import ProductCard from '../components/ProductCard';
import Loader from '../components/Loader';

const Products = () => {
  const [searchParams] = useSearchParams();
  const { isAuthenticated } = useAuth();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [filters, setFilters] = useState({
    category: searchParams.get('category') || '',
    search: searchParams.get('search') || '',
    minPrice: '',
    maxPrice: '',
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch categories (requires admin, so handle errors gracefully)
        try {
          const categoriesResponse = await api.get('/Categories/all');
          setCategories(categoriesResponse.data || []);
        } catch (err) {
          // Categories require admin, so if user is not admin, just skip categories
          console.log('Categories not available:', err.response?.status);
          setCategories([]);
        }

        // Determine which endpoint to use based on authentication and filters
        const hasFilters = filters.category || filters.search || filters.minPrice || filters.maxPrice;
        
        if (isAuthenticated && hasFilters) {
          // Use filter endpoint for authenticated users with filters
          const params = new URLSearchParams();
          if (filters.search) params.append('name', filters.search);
          if (filters.category) params.append('category', filters.category);
          if (filters.minPrice) params.append('min_price', filters.minPrice);
          if (filters.maxPrice) params.append('max_price', filters.maxPrice);
          
          const productsResponse = await api.get(`/products/filter/user?${params.toString()}`);
          setProducts(productsResponse.data || []);
        } else {
          // Use public endpoint for all products
          const productsResponse = await api.get('/products/all');
          let allProducts = productsResponse.data || [];
          
          // Apply client-side filtering if needed
          if (filters.search) {
            allProducts = allProducts.filter(p => 
              p.name?.toLowerCase().includes(filters.search.toLowerCase())
            );
          }
          if (filters.category) {
            allProducts = allProducts.filter(p => 
              p.category_name?.toLowerCase().includes(filters.category.toLowerCase())
            );
          }
          if (filters.minPrice) {
            allProducts = allProducts.filter(p => p.price >= parseFloat(filters.minPrice));
          }
          if (filters.maxPrice) {
            allProducts = allProducts.filter(p => p.price <= parseFloat(filters.maxPrice));
          }
          
          setProducts(allProducts);
        }
      } catch (err) {
        setError(err.response?.data?.detail || 'Failed to load products. Please try again later.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [filters, isAuthenticated]);

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      category: '',
      search: '',
      minPrice: '',
      maxPrice: '',
    });
  };

  if (loading) {
    return <Loader />;
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">All Products</h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <aside className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
              <h2 className="text-xl font-semibold mb-4">Filters</h2>

              {/* Category Filter */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category
                </label>
                <select
                  value={filters.category}
                  onChange={(e) => handleFilterChange('category', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Categories</option>
                  {categories.map((cat) => (
                    <option key={cat.id || cat.name} value={cat.name || cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Price Range
                </label>
                <div className="space-y-2">
                  <input
                    type="number"
                    placeholder="Min Price"
                    value={filters.minPrice}
                    onChange={(e) => handleFilterChange('minPrice', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <input
                    type="number"
                    placeholder="Max Price"
                    value={filters.maxPrice}
                    onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Search */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search
                </label>
                <input
                  type="text"
                  placeholder="Search products..."
                  value={filters.search}
                  onChange={(e) => handleFilterChange('search', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <button
                onClick={clearFilters}
                className="w-full px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Clear Filters
              </button>
            </div>
          </aside>

          {/* Products Grid */}
          <main className="flex-1">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
                {error}
              </div>
            )}

            {products.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-white rounded-lg shadow-md">
                <p className="text-lg text-gray-500 mb-4">No products found.</p>
                <p className="text-gray-400">Try adjusting your filters or search terms.</p>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default Products;
